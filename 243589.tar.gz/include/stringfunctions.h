char* subString (const char* input, char* destination, int offset, int length);
char *rstrstr(char *__restrict s1, char *__restrict s2);
